document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('participantForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('name').value;
      const studentClass = document.getElementById('class').value;
      const house = document.getElementById('house').value;
      const eventCheckboxes = form.querySelectorAll('input[type=checkbox]:checked');
      const events = Array.from(eventCheckboxes).map(cb => cb.value);
      const participant = { name, class: studentClass, house, events };
      const existing = JSON.parse(localStorage.getItem('participants') || '[]');
      existing.push(participant);
      localStorage.setItem('participants', JSON.stringify(existing));
      alert("Participant registered successfully!");
      form.reset();
    });
  }
});